//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class - 
//Lab  -

public class HistogramRunner
{
	public static void main(String args[])
	{
	}
}