import java.util.Scanner;

public class String_Lab
{
    public static void main(String[] args) 
    {
        Scanner kb = new Scanner( System.in );
        
        System.out.print( "Enter a word :: ");
        String word = kb.next();
        
        //print out the first and last letter of the word
        
        
        
        //print out the word backwords
        
        
        
        //check to see if the word contains a vowel
        
        
        
    }
}
