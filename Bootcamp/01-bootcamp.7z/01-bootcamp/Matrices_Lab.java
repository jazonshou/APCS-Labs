import java.util.Scanner;
import java.util.Arrays;

public class Matrices_Lab
{
	public static int sumMat( int[][] matty )
	{
	    int sum = 0;
	    // add up all the values from the matrix
	    // store them in sum
	    // return sum
        
		return sum;
	}
	
   public static void main(String[] args) 
   {
       int[][] mat = {{2,3,4},
                      {55,66,77},
                      {22,11}};
       
       System.out.println( sumMat( mat ) );       
   }
}
