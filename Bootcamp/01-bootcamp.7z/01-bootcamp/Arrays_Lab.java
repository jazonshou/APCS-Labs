import java.util.Scanner;
import java.util. Arrays;

public class Arrays_Lab
{
    public static void main(String[] args) 
    {
        int[] rayOne = {2,3,4,5,6,7,8,9,0,11,2,3,4,5,3};
        
        //write a loop to print out every other number in the array
        
        
        //write a loop to print out all of the numbers backwards
        
    }
}
