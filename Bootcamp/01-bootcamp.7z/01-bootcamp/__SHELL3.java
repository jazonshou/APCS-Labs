
public class __SHELL3 extends bluej.runtime.Shell {
public static void run() throws Throwable {

java.lang.String[] __bluej_param0 = { };
Matrices_Examples.main(__bluej_param0);

}}
