import java.util.List;
import java.util.ArrayList;

public class List_Lab
{
	public static int sumList( List<Integer> list )
	{
	    int sum =0;
	    // add all the elements that are inside list.
         
        sum = sum + 7;
		return sum;
	}
	
	public static void main(String[] args) 
   {
		List<Integer> nums = new ArrayList<Integer>();
		//add in some numbers to the list
		//use a loop and Math.random() if you feel froggy
		
   
   	System.out.println( sumList( nums ) );     
   }
}
