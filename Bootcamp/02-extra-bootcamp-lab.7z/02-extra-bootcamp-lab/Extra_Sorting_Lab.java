
/**
 * Write a description of class Extra_Sorting_Lab here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

import java.util.Arrays;


public class Extra_Sorting_Lab
{


    public static void main(String[] args) 
    {
        int[] array = {14,7,1,25,6,10,11,4,3,0,11};
        System.out.println ("Unsorted array");
        System.out.println ( Arrays.toString( array ) );        
        // Sort (in ascending order) the elements in the array  using loops.
        // If you are solving this problem is because you 
        // completed the bootcamp labs.
        // Please do not take shortcuts ... 
        //   Do not look at the web. 
        //   Do not copy code from a classmate
        //   Do not use Arrays.sort
        
        System.out.println ();
        System.out.println ("Sorted array");
        //print out the (resulting) sorted array
        
    }

}
